package com.example.firebaselab

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
