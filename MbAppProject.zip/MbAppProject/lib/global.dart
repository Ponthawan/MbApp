// globals.dart
library my_project.globals;

String username = "";
String card_number = "0";
