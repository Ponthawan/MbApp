import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'global.dart' as globals;

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MaterialApp(home: UserPage()));
}

class UserPage extends StatefulWidget {
  @override
  _UserPageState createState() => UserPageState();
}
